package kw.mulitplay.game.service;

public interface GameService {
}
