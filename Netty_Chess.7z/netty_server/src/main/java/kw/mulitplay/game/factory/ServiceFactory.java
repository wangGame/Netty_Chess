package kw.mulitplay.game.factory;

import kw.mulitplay.game.service.GameService;
import kw.mulitplay.game.service.PlayerRegister;

public class ServiceFactory {

}
