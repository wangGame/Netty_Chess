package kw.mulitplay.game.netty.message;

import kw.mulitplay.game.netty.message.base.Message;

public class CommonMassage extends Message {
    private String msg;
    public CommonMassage(String info){

    }
}
