package com.bluetooth;

public class BluetoothUtils {
}
