package kw.mulitplay.game.message.handler;

import io.netty.channel.SimpleChannelInboundHandler;

//public class TiaozhanHandler extends SimpleChannelInboundHandler<> {
//}
