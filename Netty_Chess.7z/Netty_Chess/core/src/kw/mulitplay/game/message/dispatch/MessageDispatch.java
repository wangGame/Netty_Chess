package kw.mulitplay.game.message.dispatch;

public class MessageDispatch {

}
