package kw.mulitplay.game.message;

import kw.mulitplay.game.message.base.Message;

public class PipeiMessage extends Message {
}
