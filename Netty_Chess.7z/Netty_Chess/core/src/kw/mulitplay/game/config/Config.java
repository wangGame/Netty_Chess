package kw.mulitplay.game.config;

public abstract class Config {
    public static final int STD_GAME_HIGHT = 1280;
    public static final int STD_GAME_WIDTH = 720;
    public static final int NOVALUE = 0;
    public static float       GAME_HIGHT = 1280;
    public static float       GAME_WIDTH = 720;
    public static float chessSize = 53*1.5F;


}
